# beav - a bacterial genome and mobile element annotation pipeline
beav: Bacteria/Element Annotation reVamped
